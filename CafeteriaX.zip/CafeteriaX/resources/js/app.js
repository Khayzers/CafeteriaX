import './bootstrap';

// Import Bootstrap
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

// Import Croppie
import Croppie from 'croppie';
window.Croppie = Croppie;
