

<?php $__env->startSection('title', 'Gestionar Menú - ' . $cafeteria->name); ?>

<?php $__env->startSection('content'); ?>
<section class="py-4 bg-light">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">
                    <i class="fas fa-utensils text-gold me-2"></i>Menú de <?php echo e($cafeteria->name); ?>

                </h2>
                <p class="text-muted mb-0"><?php echo e($menuItems->count()); ?> productos en el menú</p>
            </div>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('dueno.dashboard')); ?>" class="btn btn-outline-gold">
                    <i class="fas fa-arrow-left me-2"></i>Volver
                </a>
                <a href="<?php echo e(route('dueno.menu.create', $cafeteria->id)); ?>" class="btn btn-gold">
                    <i class="fas fa-plus-circle me-2"></i>Nuevo Item
                </a>
            </div>
        </div>

        <?php if($menuItems->isEmpty()): ?>
            <div class="card card-elegant">
                <div class="card-body text-center py-5">
                    <i class="fas fa-utensils fa-5x text-gold mb-4" style="opacity: 0.3;"></i>
                    <h3>No hay items en el menú</h3>
                    <p class="text-muted mb-4">Comienza agregando productos a tu menú</p>
                    <a href="<?php echo e(route('dueno.menu.create', $cafeteria->id)); ?>" class="btn btn-gold">
                        <i class="fas fa-plus-circle me-2"></i>Agregar Primer Item
                    </a>
                </div>
            </div>
        <?php else: ?>
            <?php
                $groupedItems = $menuItems->groupBy('category.name');
            ?>

            <?php $__currentLoopData = $groupedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-elegant mb-4">
                    <div class="card-header bg-white border-bottom">
                        <h5 class="mb-0 text-gold">
                            <?php echo e($items->first()->category->emoji ?? ''); ?> <?php echo e($categoryName); ?>

                            <span class="badge bg-light text-dark ms-2"><?php echo e($items->count()); ?></span>
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th style="width: 80px;">Imagen</th>
                                        <th>Nombre</th>
                                        <th>Descripción</th>
                                        <th style="width: 120px;">Precio</th>
                                        <th style="width: 100px;">Estado</th>
                                        <th style="width: 150px;" class="text-end">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($item->image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $item->image)); ?>" 
                                                         alt="<?php echo e($item->name); ?>" 
                                                         class="rounded" 
                                                         style="width: 60px; height: 60px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                                         style="width: 60px; height: 60px;">
                                                        <i class="fas fa-image text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <strong><?php echo e($item->name); ?></strong>
                                                <?php if($item->allergens): ?>
                                                    <br>
                                                    <small class="text-danger">
                                                        <i class="fas fa-exclamation-triangle"></i>
                                                        <?php if(is_array($item->allergens)): ?>
                                                            <?php echo e(implode(', ', $item->allergens)); ?>

                                                        <?php else: ?>
                                                            <?php echo e($item->allergens); ?>

                                                        <?php endif; ?>
                                                    </small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <small class="text-muted"><?php echo e(Str::limit($item->description, 50)); ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-gold">$<?php echo e(number_format($item->price, 0, ',', '.')); ?></span>
                                            </td>
                                            <td>
                                                <?php if($item->is_available): ?>
                                                    <span class="badge bg-success">Disponible</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">No disponible</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end">
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <a href="<?php echo e(route('dueno.menu.edit', [$cafeteria->id, $item->id])); ?>" 
                                                       class="btn btn-outline-gold">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('dueno.menu.destroy', [$cafeteria->id, $item->id])); ?>" 
                                                          method="POST" 
                                                          class="d-inline"
                                                          onsubmit="return confirm('¿Estás seguro de eliminar este item?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-outline-danger">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sebastian.vera\Desktop\Proyectos DEF\CafeteriaX\resources\views/dueno/menu/index.blade.php ENDPATH**/ ?>