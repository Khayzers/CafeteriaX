

<?php $__env->startSection('title', 'Editar Item - ' . $cafeteria->name); ?>

<?php $__env->startPush('styles'); ?>
<style>
#cropperModal .modal-dialog {
    max-width: 800px;
}
#cropperModal .modal-body {
    overflow: visible !important;
}
.cropper-container {
    direction: ltr;
    font-size: 0;
    line-height: 0;
    position: relative;
    touch-action: none;
    user-select: none;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card card-elegant">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h2 class="mb-0">
                                <i class="fas fa-edit text-gold me-2"></i>Editar Item del Menú
                            </h2>
                            <a href="<?php echo e(route('dueno.menu.index', $cafeteria->id)); ?>" class="btn btn-outline-gold">
                                <i class="fas fa-arrow-left me-2"></i>Volver
                            </a>
                        </div>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('dueno.menu.update', [$cafeteria->id, $menuItem->id])); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="row g-3 mb-4">
                                <div class="col-12">
                                    <h5 class="text-gold mb-3">
                                        <i class="fas fa-info-circle me-2"></i>Información del Producto
                                    </h5>
                                </div>

                                <div class="col-md-8">
                                    <label for="name" class="form-label">Nombre *</label>
                                    <input type="text" class="form-control form-control-elegant" id="name" name="name" 
                                           value="<?php echo e(old('name', $menuItem->name)); ?>" required>
                                </div>

                                <div class="col-md-4">
                                    <label for="category_id" class="form-label">Categoría *</label>
                                    <select class="form-select form-control-elegant" id="category_id" name="category_id" required>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id', $menuItem->category_id) == $category->id ? 'selected' : ''); ?>>
                                                <?php echo e($category->emoji); ?> <?php echo e($category->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-12">
                                    <label for="description" class="form-label">Descripción</label>
                                    <textarea class="form-control form-control-elegant" id="description" name="description" 
                                              rows="3"><?php echo e(old('description', $menuItem->description)); ?></textarea>
                                </div>

                                <div class="col-md-6">
                                    <label for="price" class="form-label">Precio (CLP) *</label>
                                    <input type="number" class="form-control form-control-elegant" id="price" name="price" 
                                           value="<?php echo e(old('price', $menuItem->price)); ?>" min="0" step="100" required>
                                </div>

                                <div class="col-md-6">
                                    <label for="preparation_time" class="form-label">Tiempo de Preparación (minutos)</label>
                                    <input type="number" class="form-control form-control-elegant" id="preparation_time" name="preparation_time" 
                                           value="<?php echo e(old('preparation_time', $menuItem->preparation_time)); ?>" min="0">
                                </div>

                                <div class="col-12">
                                    <label class="form-label">Alérgenos</label>
                                    <div class="row g-2">
                                        <?php
                                            $alergenos = ['gluten', 'lactosa', 'nueces', 'soja', 'huevo', 'pescado', 'mariscos', 'sésamo'];
                                            $selectedAlergenos = old('allergens', $menuItem->allergens ?? []);
                                        ?>
                                        <?php $__currentLoopData = $alergenos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alergeno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="allergens[]" value="<?php echo e($alergeno); ?>" 
                                                           id="allergen_<?php echo e($alergeno); ?>"
                                                           <?php echo e(in_array($alergeno, $selectedAlergenos) ? 'checked' : ''); ?>>
                                                    <label class="form-check-label text-capitalize" for="allergen_<?php echo e($alergeno); ?>">
                                                        <?php echo e($alergeno); ?>

                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="is_available" name="is_available" 
                                               <?php echo e(old('is_available', $menuItem->is_available) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="is_available">
                                            Disponible para la venta
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="row g-3 mb-4">
                                <div class="col-12">
                                    <h5 class="text-gold mb-3">
                                        <i class="fas fa-image me-2"></i>Imagen del Producto
                                    </h5>
                                </div>

                                <div class="col-12">
                                    <?php if($menuItem->image): ?>
                                        <div class="mb-3">
                                            <label class="form-label">Imagen Actual</label>
                                            <div>
                                                <img src="<?php echo e(asset('storage/' . $menuItem->image)); ?>" 
                                                     alt="Imagen actual" class="img-thumbnail" style="width: 150px; height: 150px; object-fit: cover;">
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <label for="imageInput" class="form-label"><?php echo e($menuItem->image ? 'Cambiar Imagen' : 'Nueva Imagen'); ?></label>
                                    <input type="file" class="form-control form-control-elegant" id="imageInput" accept="image/*">
                                    <input type="hidden" name="image" id="croppedImage" disabled>
                                    <small class="text-muted">Formato: JPG, PNG. Tamaño máx: 4MB. La imagen será recortada en formato cuadrado.</small>
                                </div>
                                
                                <!-- Modal para recortar imagen -->
                                <div class="modal fade" id="cropperModal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header bg-dark">
                                                <h5 class="modal-title text-gold">
                                                    <i class="fas fa-crop-alt me-2"></i>Recortar Imagen
                                                </h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body" style="padding: 20px; background: #000;">
                                                <div style="width: 100%; max-width: 600px; margin: 0 auto;">
                                                    <img id="imageToCrop" style="max-width: 100%; display: block;">
                                                </div>
                                            </div>
                                            <div class="modal-footer bg-light">
                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                                    <i class="fas fa-times me-2"></i>Cancelar
                                                </button>
                                                <button type="button" class="btn btn-gold" id="cropButton">
                                                    <i class="fas fa-check me-2"></i>Aplicar Recorte
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Preview de nueva imagen recortada -->
                                <div class="col-12" id="previewContainer" style="display: none;">
                                    <label class="form-label">Nueva Vista Previa</label>
                                    <div class="d-flex align-items-center gap-3">
                                        <img id="croppedPreview" class="rounded shadow" style="width: 150px; height: 150px; object-fit: cover;">
                                        <button type="button" class="btn btn-outline-gold btn-sm" onclick="document.getElementById('imageInput').click()">
                                            <i class="fas fa-sync-alt me-2"></i>Cambiar Imagen
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex gap-3 justify-content-end pt-3 border-top">
                                <a href="<?php echo e(route('dueno.menu.index', $cafeteria->id)); ?>" class="btn btn-outline-gold px-4">
                                    <i class="fas fa-times me-2"></i>Cancelar
                                </a>
                                <button type="submit" class="btn btn-gold px-4">
                                    <i class="fas fa-save me-2"></i>Guardar Cambios
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
let cropper;
const imageInput = document.getElementById('imageInput');
const imageToCrop = document.getElementById('imageToCrop');
const cropperModalElement = document.getElementById('cropperModal');
const cropButton = document.getElementById('cropButton');
const croppedPreview = document.getElementById('croppedPreview');
const previewContainer = document.getElementById('previewContainer');
const croppedImageInput = document.getElementById('croppedImage');

imageInput.addEventListener('change', function(e) {
    const files = e.target.files;
    if (files && files.length > 0) {
        const file = files[0];
        
        if (file.size > 4 * 1024 * 1024) {
            alert('La imagen no debe superar los 4MB');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(event) {
            imageToCrop.src = event.target.result;
            
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
            
            // Abrir el modal primero
            const btn = document.createElement('button');
            btn.setAttribute('data-bs-toggle', 'modal');
            btn.setAttribute('data-bs-target', '#cropperModal');
            btn.style.display = 'none';
            document.body.appendChild(btn);
            btn.click();
            document.body.removeChild(btn);
        };
        reader.readAsDataURL(file);
    }
});

// Inicializar cropper DESPUÉS de que el modal se muestre
cropperModalElement.addEventListener('shown.bs.modal', function() {
    if (!cropper && imageToCrop.src && imageToCrop.complete) {
        cropper = new Cropper(imageToCrop, {
            aspectRatio: 1,
            viewMode: 0,
            dragMode: 'move',
            autoCropArea: 0.65,
            restore: false,
            guides: false,
            center: false,
            highlight: false,
            cropBoxMovable: true,
            cropBoxResizable: true,
            toggleDragModeOnDblclick: false,
        });
    }
});

cropButton.addEventListener('click', function() {
    if (cropper) {
        const canvas = cropper.getCroppedCanvas({
            width: 500,
            height: 500,
            imageSmoothingQuality: 'high'
        });
        
        canvas.toBlob(function(blob) {
            const url = URL.createObjectURL(blob);
            croppedPreview.src = url;
            previewContainer.style.display = 'block';
            
            const reader = new FileReader();
            reader.onloadend = function() {
                croppedImageInput.value = reader.result;
                croppedImageInput.disabled = false;
            };
            reader.readAsDataURL(blob);
            
            // Cerrar modal usando data-bs-dismiss
            const closeBtn = cropperModalElement.querySelector('[data-bs-dismiss="modal"]');
            if (closeBtn) closeBtn.click();
        });
    }
});

// Limpiar cropper cuando se cierra el modal
cropperModalElement.addEventListener('hidden.bs.modal', function() {
    if (cropper) {
        cropper.destroy();
        cropper = null;
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sebastian.vera\Desktop\Proyectos DEF\CafeteriaX\resources\views/dueno/menu/edit.blade.php ENDPATH**/ ?>