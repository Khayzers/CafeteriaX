

<?php $__env->startSection('title', 'Registrarse - CafeteriaX'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5 bg-gray-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-8">
                <div class="card border-0 shadow-lg">
                    <div class="card-body p-5">
                        <div class="text-center mb-4">
                            <div class="icon-circle mx-auto mb-3">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <h2 class="mb-2">Crear Cuenta</h2>
                            <p class="text-muted">Únete a CafeteriaX y descubre las mejores cafeterías</p>
                        </div>

                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>

                            <!-- Nombre -->
                            <div class="mb-3">
                                <label for="name" class="form-label-elegant">Nombre Completo</label>
                                <input 
                                    type="text" 
                                    class="form-control form-control-elegant <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="name" 
                                    name="name" 
                                    value="<?php echo e(old('name')); ?>" 
                                    required 
                                    autofocus
                                    placeholder="Ej: Juan Pérez"
                                >
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Email -->
                            <div class="mb-3">
                                <label for="email" class="form-label-elegant">Correo Electrónico</label>
                                <input 
                                    type="email" 
                                    class="form-control form-control-elegant <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="email" 
                                    name="email" 
                                    value="<?php echo e(old('email')); ?>" 
                                    required
                                    placeholder="tu@email.com"
                                >
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Teléfono (Opcional) -->
                            <div class="mb-3">
                                <label for="phone" class="form-label-elegant">Teléfono <span class="text-muted">(Opcional)</span></label>
                                <input 
                                    type="tel" 
                                    class="form-control form-control-elegant <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="phone" 
                                    name="phone" 
                                    value="<?php echo e(old('phone')); ?>"
                                    placeholder="+34 600 000 000"
                                >
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Contraseña -->
                            <div class="mb-3">
                                <label for="password" class="form-label-elegant">Contraseña</label>
                                <input 
                                    type="password" 
                                    class="form-control form-control-elegant <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="password" 
                                    name="password" 
                                    required
                                    placeholder="Mínimo 8 caracteres"
                                >
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Confirmar Contraseña -->
                            <div class="mb-4">
                                <label for="password_confirmation" class="form-label-elegant">Confirmar Contraseña</label>
                                <input 
                                    type="password" 
                                    class="form-control form-control-elegant" 
                                    id="password_confirmation" 
                                    name="password_confirmation" 
                                    required
                                    placeholder="Repite tu contraseña"
                                >
                            </div>

                            <!-- Info sobre rol -->
                            <div class="alert alert-info border-0 mb-4">
                                <i class="fas fa-info-circle me-2"></i>
                                <small>Te registrarás como <strong>Cliente</strong>. Si tienes una cafetería y deseas registrarla, <a href="mailto:contacto@cafeteriax.com" class="text-decoration-underline">contáctanos</a>.</small>
                            </div>

                            <!-- Botón Registro -->
                            <button type="submit" class="btn btn-gold w-100 py-3 mb-3">
                                <i class="fas fa-user-plus me-2"></i>Crear Cuenta
                            </button>

                            <!-- Link a Login -->
                            <div class="text-center">
                                <p class="mb-0 text-muted">
                                    ¿Ya tienes cuenta? 
                                    <a href="<?php echo e(route('login')); ?>" class="text-gold text-decoration-none fw-semibold">Inicia Sesión</a>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Beneficios de Registro -->
                <div class="row g-3 mt-4">
                    <div class="col-4">
                        <div class="text-center">
                            <i class="fas fa-heart fa-2x text-gold mb-2"></i>
                            <p class="small mb-0">Guarda favoritos</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="text-center">
                            <i class="fas fa-star fa-2x text-gold mb-2"></i>
                            <p class="small mb-0">Recomendaciones</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="text-center">
                            <i class="fas fa-bell fa-2x text-gold mb-2"></i>
                            <p class="small mb-0">Notificaciones</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sebastian.vera\Desktop\Proyectos DEF\CafeteriaX\resources\views/auth/register.blade.php ENDPATH**/ ?>